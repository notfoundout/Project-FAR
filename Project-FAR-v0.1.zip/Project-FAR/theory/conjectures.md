# Conjectures

1. Representation conjecture.
2. Ω irreducibility conjecture.
3. Primitive independence conjecture.
