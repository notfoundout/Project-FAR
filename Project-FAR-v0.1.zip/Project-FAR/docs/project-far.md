# Project FAR

Mission: Discover or refute a minimal architecture for structured, explicit, auditable reasoning.
