# FARA

Candidate foundational architecture.
