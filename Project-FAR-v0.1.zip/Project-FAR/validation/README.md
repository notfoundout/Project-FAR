# Validation

External comparisons and attempted falsifications.
